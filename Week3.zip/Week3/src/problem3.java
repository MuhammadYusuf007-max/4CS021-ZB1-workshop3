public class problem3 {
    public static String calculate(int percentage) {
        if (percentage >= 70) {
            return "A";
        } else if (percentage >= 60) {
            return "B";
        } else if (percentage >= 50) {
            return "C";
        } else if (percentage >= 40) {
            return "D";
        } else {
            return "Fail";
        }
    }

public static void main(String[] args) {
    // Example usage
    int[] testPercentages = {85, 67, 54, 45, 38};

    for (int percentage : testPercentages) {
        System.out.println("Percentage: " + percentage + " -> Classification: " + calculate(percentage));
    }
}
}


