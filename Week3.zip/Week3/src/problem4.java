public class problem4 {

    public static void dispenseChange(int cost, int totalChange) {
        int change = totalChange - cost;

        if (change < 0) {
            System.out.println("Insufficient amount provided.");
            return;
        }

        System.out.println("Change to be dispensed: " + change + " pence");

        int[] denominations = {100, 50, 20, 10, 5, 2, 1};
        String[] denominationNames = {"£1", "50p", "20p", "10p", "5p", "2p", "1p"};

        for (int i = 0; i < denominations.length; i++) {
            int count = change / denominations[i];
            if (count > 0) {
                System.out.println(count + " x " + denominationNames[i]);
                change %= denominations[i];
            }
        }
    }

    public static void main(String[] args) {
        int cost = 135;
        int totalChange = 330;

        dispenseChange(cost, totalChange);
    }
}
