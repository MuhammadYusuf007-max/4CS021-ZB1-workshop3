import java.util.Scanner;

public class Main {

    public static void introduce(String name, int age, double height) {
        System.out.println("Hi, my name is " + name + ", I am " + age + " years old and I am " + height + " feet tall.");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Enter username");
        String userName = scanner.nextLine();
        introduce(userName, 20, 180);  // Call introduce with correct parameter sequence
    }
}

