public class problem5 {

    public static void sum(int number){
        int a = 0;

        if (number < 1) {
            System.out.println("Please enter positive number.");
            return;
        }

        for (int i=0; i<(number+1); i++){
            a = a + i;
        }
        System.out.println(a);
    }


    public static void main(String[] args) {
        int number = 10;
        sum(number);
    }

}
